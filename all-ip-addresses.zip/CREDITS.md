Original code was forked from Josholith, and had been released under GPL3.
https://github.com/Josholith/gnome-extension-lan-ip-address
